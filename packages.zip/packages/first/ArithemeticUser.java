import aits.*;
class ArithemeticUser{
	public static void main(String[] args){
		Arithmetic ar=new Arithmetic();
		double ad=ar.add(2,5);
		double sb=ar.subtract(9,7);
		double ml=ar.multiply(9,7);
		double dv=ar.divide(7,9);
		System.out.println("add(),subtract(),mul(),divide() methods called from aits package Arithemetic class");
		System.out.println("Addition="+ad);
		System.out.println("Subtraction="+sb);
		System.out.println("Multiplication="+ml);
		System.out.println("Division="+dv);
	}
}	