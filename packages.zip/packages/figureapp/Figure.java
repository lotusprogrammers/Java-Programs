package p2;
public interface Figure{
	void display();
	double area();
}	