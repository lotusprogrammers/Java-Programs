//This program imports classes from p2 package.
import p2.*;
class FigureUser{
	public static void main(String[] args){
		Figure f;
		//Figure reference f assigned with RectangleFigure object
		f=new RectangleFigure(2,5);
		f.display();
		double ra=f.area();
		System.out.println("RectangleFigure area="+ra);
		//Figure reference f assigned with TraingleFigure object
		f=new TraingleFigure(5,7);
		f.display();
		double ta=f.area();
		System.out.println("Traingle area"+ta);
	}
}	
