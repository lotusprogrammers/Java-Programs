package p2;
public class RectangleFigure extends AbstractFigure{
	public RectangleFigure(){
		super();
	}
    public RectangleFigure(double dim1,double dim2){
		super(dim1,dim2);
	}
    public double area(){
		return (dim1*dim2);
	}
}	
		
		